package com.shopkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopKart1Application {

	public static void main(String[] args) {
		SpringApplication.run(ShopKart1Application.class, args);
	}

}
