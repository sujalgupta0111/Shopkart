package com.shopkart.service;

public interface CommonService {

	public void removeSessionMessage();

}
